#!/usr/bin/env python3
#import libraries
import rospy
#import from services : TurnCamera and TurnCameraResponse
from my_robot_tutorial.srv import TurnCamera, TurnCameraResponse
#import os library for paths
import os
#import image libraries, cv2 to read and access images, cv_bridge to convert images to ROS messages
import cv2
from cv_bridge import CvBridge

class TurnCameraClass:
    #initial function
    def __init__(self):
        #set available angles
        self.available_angles = [-30,-15,0,15,30]
        #Call the service TurnCamera and call send_image with the request of the client (req)
        self.ros_service = rospy.Service("turn_camera", TurnCamera, self.send_image)

    def read_in_image_by_file_name(self, file_name):
        #set the path of the current file
        dir_name= os.path.dirname(__file__)
        #add to path "/images/" and the name of the image to return
        file_location= dir_name + "/images/"+ file_name
        #read the image with cv2
        image = cv2.imread(file_location)
        #retrun the image
        return image

    def get_image(self, angle):
        #calculate distance between given angle and available angle and take the closest from available angles
        closest_angle = min(self.available_angles, key=lambda x:abs(x-angle))
        # return what call read_in_image_by_file_name returns ( call with parameter str of closest angle.png, for example "45.png")
        return self.read_in_image_by_file_name(str(closest_angle)+".png")

    def send_image(self, req):
        #call get_image
        image = self.get_image(req.turn_degrees)
        #convert image retreived to ROS image message
        image_msg = CvBridge().cv2_to_imgmsg(image)
        #teturn the ROS image message version using TurnCameraResponse service
        return TurnCameraResponse (image_msg)

#main
if __name__ == "__main__":
    try:
        #set node turn_camera_service_node
        rospy.init_node("turn_camera_service_node")
        #call TurnCameraClass
        TurnCameraClass()
        print("Turn Camera service is Running")
        rospy.spin()

    except rospy.ROSInterruptException:
        pass
