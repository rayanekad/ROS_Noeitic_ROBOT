#impoty libraries
import rospy

from std_msgs.msg import String, Float32

#data in callback_function is the value recovered from rpm topic
def callback_function(data):

    print("Msg received: " + str(data))
    #create a handle to publish on topic speed
    pub = rospy.Publisher('speed',Float32, queue_size=10)
    #set radius
    radius = 10
    #calculate speed usin radius and rpm
    speed = radius*3.14*(data.data)
    #publish speed
    pub.publish(speed)

def sub_function():
    #initiate node2
    rospy.init_node("node2")
    #subscribe to rpm topic and call callback_function
    pub = rospy.Subscriber('rpm',Float32, callback_function)


if __name__ == "__main__":
    #call sub_function
    sub_function()
    rospy.spin()
