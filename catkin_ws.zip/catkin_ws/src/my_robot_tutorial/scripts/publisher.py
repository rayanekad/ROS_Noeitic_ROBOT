#import libraries
import rospy

from std_msgs.msg import String

def pub_function():
    #create a node
    rospy.init_node("pub_function_node")
    #create a handle to publish String in pub_msg topic
    pub = rospy.Publisher('pub_msg',String, queue_size=10)

    i = 0
    rate = rospy.Rate(5)
    while not rospy.is_shutdown():
        #publih string(i)
        pub.publish("This is a published message" + str(i))
        i+=1
        rate.sleep()

if __name__ == "__main__":
    try:
        #call function pub_function
        pub_function()
    except rospy.ROSInterruptException:
        pass
