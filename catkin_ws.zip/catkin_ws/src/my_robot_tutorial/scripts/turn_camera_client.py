#!/usr/bin/env python3
#import libraries
import rospy
#import from services : TurnCamera and TurnCameraResponse
from my_robot_tutorial.srv import TurnCamera, TurnCameraResponse
#import os library for paths
import os
#import image libraries, cv2 to read and access images, cv_bridge to convert ROS messages to images
import cv2
from cv_bridge import CvBridge


def configure_request(angle):
    #wait for the turn_camera service
    rospy.wait_for_service("turn_camera")
    try:
        #connect to TurnCamera
        Service_proxy= rospy.ServiceProxy("turn_camera", TurnCamera)
        #get the reponse message which is a ROS image message
        resp_msg= Service_proxy(angle)
        # ger the image from the response
        image_msg= resp_msg.image
        #convert ROS image message to image
        image=CvBridge().imgmsg_to_cv2(image_msg, desired_encoding="passthrough")
        #display the returned message
        cv2.imshow("Turn Camera Image",image)
        #wait till image is closed
        cv2.waitKey(0)
        #destroy all windows
        cv2.destroyAllWindows()

    except rospy.ServiceException as e:
        print("Service Request Failed")
        print(e)


#main
if __name__ == "__main__":
    try:
        #create node turn_camera_client_node
        rospy.init_node("turn_camera_client_node")
        #get angle requested from client via input from terminal
        user_input= input("\n Enter an angle degrees to move the robot Camera:")
        while user_input != "q":
            try:
                # call configure_request with parameter the requested angle angle
                configure_request(float(user_input))
                #ask again for another angle
                user_input = input("\n Enter another angle degrees to move robot camera:")

            except:
                print("Error Trying to process request")


    except rospy.ROSInterruptException:
        pass
