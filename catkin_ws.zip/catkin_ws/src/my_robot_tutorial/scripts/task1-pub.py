#import libraries
import rospy

from std_msgs.msg import Float32, String

def pub_function():
    #initiate node1
    rospy.init_node('node1')
    #create a handle to publish in rpm topic
    pub = rospy.Publisher('rpm',Float32, queue_size=10)
    #set value
    rpm = Float32(10)

    rate = rospy.Rate(5)
    while not rospy.is_shutdown():
        #publish rpm variable
        pub.publish(rpm)
        rate.sleep()

#main
if __name__ == "__main__":
    try:
        #call pub_function
        pub_function()
    except rospy.ROSInterruptException:
        pass
