#import libraries
import rospy

from std_msgs.msg import String

def callback_function(data):
    #print the message received
    print("Msg received: " + str(data))

def sub_function():
    #initiate the subscriber node
    rospy.init_node("sub_function_node")
    #subscribe to pub_msg, get value and call callback_function
    pub = rospy.Subscriber('pub_msg',String, callback_function)



if __name__ == "__main__":
    #call function sub_function
    sub_function()
    rospy.spin()
