#!/usr/bin/env python3
#first line to set python3
#import libraries
import rospy

from std_msgs.msg import Float64

#wheel_radius = rospy.get_param("/wheel_radius")

#this function takes as input a handle publisher for speed and an rpm value
def calc_speed(rpm,publisher):
    #get parameter server "/wheel_radius"
    wheel_radius= rospy.get_param("/wheel_radius")
    #calculate speed
    speed = rpm.data*2*3.14159/60*wheel_radius
    #publish speed 
    publisher.publish(speed)

def create_subscriber(pub):
        #subscribe to "rpm" topic and call calc_speed ( associate with it publisher and the retrieved rpm value)
        rospy.Subscriber("rpm",Float64,calc_speed,(pub))

def speed_pub():

    return pub


if __name__ == "__main__":
    #initiate node speed_calc_sub_node
    rospy.init_node("speed_calc_sub_node")
    # set handle to publish in topic "speed"
    pub=rospy.Publisher("speed",Float64, queue_size=10)
    #call function create_subscriber
    create_subscriber(pub)
    rospy.spin()
