#import library
import rospy

if __name__ == '__main__':
    #create the node
    rospy.init_node('my_first_python_node')
    rospy.loginfo('This node has feedback')

    rate = rospy.Rate(10)
    #while node is running, pring "hello there"
    while not rospy.is_shutdown():
        rospy.loginfo('Hello there')
        rate.sleep()
