#!/usr/bin/env python3
#the first line is to set the environement that the .py code will excecuted in. The goal is to avoid specifying python3 everytime we run the code from the terminal
import rospy
from std_msgs.msg import Float64

rpm_num = 1
#wheel_radius = rospy.get_param("/wheel_radius")

def rpm_pub():
    #initiate the node rpm_pub_node
    rospy.init_node("rpm_pub_node")
    #set handle to publish rpm value
    pub = rospy.Publisher("rpm",Float64, queue_size=10)
    rate = rospy.Rate(5)
    while not rospy.is_shutdown():
        #publish rpm_num
        pub.publish(rpm_num)
        rate.sleep()

if __name__ == "__main__":
    try:
        #call rpm_pub function
        rpm_pub()

    except rospy.ROSInterruptException:
        pass
