#!/usr/bin/env python3
#the first line is used to define which version pf python to excute the code with

#import libraries
import rospy
import actionlib
from my_robot_tutorial.msg import navigate2DAction, navigate2DFeedback, navigate2DResult
from geometry_msgs.msg import Point
import math

#define the class of the server
class Navigate2DClass:
    def __init__(self):
        #connect to navigate2DAction Action; receive goal variable from it, lunch navigate_cb
        self.action_server = actionlib.SimpleActionServer("navigate_2D_action" , navigate2DAction , self.navigate_cb)
        #subscribe to robot/point variable and update current positoin from it (at first this is the start point defined by the user in code robot_point_sub.py)
        self.robot_point_sub = rospy.Subscriber("robot/point" , Point , self.update_robot_position)
        #initialize current point and goal point to none
        self.robot_current_point = None
        self.robot_goal_point = None
        #define the distance_threshold
        self.distance_threshold = 0.35
        self.feedback_rate = rospy.Rate(1)


    def navigate_cb(self,goal):
        #get starting time
        navigate_start_time = rospy.get_time
        #create an array position in 3D for goal point (this value is given my the client and received via the Action)
        self.robot_goal_point = [goal.point.x, goal.point.y , goal.point.z]


        #if the variable retreived from robot_point_pub.py about current position is not received, print point not detected
        while self.robot_current_point == None:
            print("Robot Point Not Detected")
            rospy.sleep(5)
        print("Robot Point detected")
        # calculate distance to goal using current point and goal point
        distance_to_goal = math.dist(self.robot_current_point , self.robot_goal_point)

        #while goal not attained, continue same procedure: publish the feedback (distance to goal) and get value from robot_point_sub
        while distance_to_goal > self.distance_threshold:
            #publish feedback using navigate2DFeedback
            self.action_server.publish_feedback(navigate2DFeedback(distance_to_point = distance_to_goal))
            self.feedback_rate.sleep()
            #caclulate distance again
            distance_to_goal = math.dist(self.robot_current_point , self.robot_goal_point)
        #once the distance in less than distance_threshold,  send result (elapsed_time)
        navigate_end_time = rospy.get_time()
        elapsed_time = navigate_end_time - navigate_start_time
        rospy.loginfo("Navigate scucessfulm elapsed time " + str(elapsed_time) + " seconds")
        #send results of the action to client using navigate2DResult
        self.action_server.set_succeeded(navigate2DResult(elapsed_time))

    #update current position
    def update_robot_position(self, point):
        self.robot_current_point = [point.x , point.y , point.z]

#main
if __name__ == '__main__':

    # create the navigate_2D_action_sever_node node
    rospy.init_node("navigate_2D_action_sever_node")
    #call the class
    server = Navigate2DClass()
    rospy.spin()
