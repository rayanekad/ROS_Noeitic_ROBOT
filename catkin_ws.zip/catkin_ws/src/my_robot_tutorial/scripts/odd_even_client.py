#!/usr/bin/env python3
#set python3

import rospy
#call OddEvenCheck OddEvenCheckResponse services
from my_robot_tutorial.srv import OddEvenCheck, OddEvenCheckResponse

#main
if __name__ == "__main__":
    #initiate node odd_even_client_node
    rospy.init_node("odd_even_client_node")
    #call service OddEvenCheck
    srv_proxy=rospy.ServiceProxy("odd_even_check", OddEvenCheck)
    #get the value to check from input terminal
    user_input= input("\nEnter a whole number:")

    # send value through service and receive response
    resp_obj = srv_proxy(int(user_input))
    #get answer from the response
    answer=resp_obj.answer
    #print the answer
    print(answer)
