#!/usr/bin/env python3
#set python3
#import libraries
import rospy
#call OddEvenCheck OddEvenCheckResponse services
from my_robot_tutorial.srv import OddEvenCheck, OddEvenCheckResponse

def check_number(req):
    #if number is even check="even", else check)="odd"
    if (req.number % 2)== 0:
        check="even"
    else:
        check ="odd"
    #send response of check using OddEvenCheckResponse
    return OddEvenCheckResponse(check)

#main
if __name__ == "__main__":
    try:
        #create node
        rospy.init_node("odd_even_service_node")
        #provide service OddEvenCheck and call function check_number with the parameter retrieved from service
        rospy.Service("odd_even_check",OddEvenCheck, check_number)
        rospy.spin()

    except rospy.ROSInterruptException:
        pass
