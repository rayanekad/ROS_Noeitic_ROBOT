#!/usr/bin/env python3

#import libraries
import rospy
import actionlib
#call action fucntions : action, action_feedback, action_result, action goal
from my_robot_tutorial.msg import navigate2DAction, navigate2DFeedback, navigate2DResult,navigate2DGoal
from geometry_msgs.msg import Point
import math

def feedback_callback(feedback):
    print("Distance to Goal: " + str(feedback.distance_to_point))

def nav_client(user_coords):
    #Start navigate2DAction Action
    client = actionlib.SimpleActionClient("navigate_2D_action" , navigate2DAction)
    client.wait_for_server()

    #assign the input variables to goal of the action
    point_msg = Point(x = user_coords[0], y = user_coords[1] , z = user_coords[2])
    goal = navigate2DGoal(point_msg)
    #get feedback
    client.send_goal(goal , feedback_cb = feedback_callback)
    #get result
    client.wait_for_result()
    return client.get_result

#main
if __name__ == '__main__':

        #create navigate_2D_action_client_node node
        rospy.init_node("navigate_2D_action_client_node")
        #retreive goal coordinates from terminal (input)
        user_x = input("What is your desired x-coordinate?: ")
        user_y = input("What is your desired y-coordinate?: ")
        user_z = input("What is your desired z-coordinate?: ")
        #assemble in one array
        user_coords = [float(user_x) , float(user_y) , float(user_z)]
        #call function nav_client
        result = nav_client(user_coords)
        #print result
        print(result)
